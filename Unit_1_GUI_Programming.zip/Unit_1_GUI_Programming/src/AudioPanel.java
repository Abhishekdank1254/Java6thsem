import java.io.*;
import javax.swing.*;

public class AudioPanel extends JPanel {
	public AudioPanel() {
		try {
			File file=new File("piano.wav");
			
			{
				
			}
		}
		catch(Exception e)
		{
			
		}
	}
}
